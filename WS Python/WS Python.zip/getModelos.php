<?php

include("wsLeere.class.php");
$ws = new wsLeere();
$s = $ws->getModelos();
echo $s;

?>
