<?php

include("wsLeere.class.php");
$ws = new wsLeere();
$s = $ws->getAutores();
echo $s;

?>
