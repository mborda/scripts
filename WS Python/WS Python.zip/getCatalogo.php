<?php

include("wsLeere.class.php");
$ws = new wsLeere();
$s = $ws->getCatalogo();
echo $s;

?>
