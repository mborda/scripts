<?php

include("wsLeere.class.php");
$ws = new wsLeere();
$s = $ws->getEditoriales();
echo $s;

?>
