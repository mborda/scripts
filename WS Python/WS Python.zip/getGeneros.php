<?php

include("wsLeere.class.php");
$ws = new wsLeere();
$s = $ws->getGeneros();
echo $s;

?>
